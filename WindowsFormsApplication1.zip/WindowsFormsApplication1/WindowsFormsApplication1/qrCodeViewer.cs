﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApplication1
{
    public partial class qrCodeViewer : PictureBox
    {
        int y = 0;
        public Timer _timer;

        public qrCodeViewer()
        {
            //InitializeComponent();
        }

        public void _timer_Tick(object sender, EventArgs e)
        {
            y += 10;
            if (y >= 300)
            {
                y = 0;
            }
            Invalidate();
        }

        protected override void OnPaint(PaintEventArgs pe)
        {
            base.OnPaint(pe);
            Graphics g = pe.Graphics;
            g.DrawLine(new Pen(Color.Red, 2f), new Point(0, y), new Point(360, y));            
        }
    }
}
