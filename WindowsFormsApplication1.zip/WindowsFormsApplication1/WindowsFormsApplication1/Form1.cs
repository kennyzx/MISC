﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApplication1
{
    public partial class Form1 : Form
    {
        qrCodeViewer qrRealTime;
        Timer _timer;
        public Form1()
        {
            InitializeComponent();
            qrRealTime = new qrCodeViewer();
            qrRealTime.Width = 300;
            qrRealTime.Height = 300;
            this.Controls.Add(qrRealTime);

            this.Load += Form1_Load;
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            qrRealTime._timer = new Timer();
            qrRealTime._timer.Start();
            qrRealTime._timer.Interval = 50;
            qrRealTime._timer.Tick += new EventHandler(qrRealTime._timer_Tick);

            _timer = new Timer();
            _timer.Interval = 2500;
            _timer.Start();
            _timer.Tick += new EventHandler(TimerEventProcessor);
        }

        private void TimerEventProcessor(object sender, EventArgs e)
        {
            qrRealTime.Image = Bitmap.FromFile(@"C:\Users\43910863\Desktop\Trash\untitled.png");
        }
    }
}
